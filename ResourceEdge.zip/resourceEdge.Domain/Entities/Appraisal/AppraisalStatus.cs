﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace resourceEdge.Domain.Entities
{
    public class AppraisalStatus
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
