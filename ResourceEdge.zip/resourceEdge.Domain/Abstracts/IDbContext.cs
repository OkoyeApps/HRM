﻿using resourceEdge.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace resourceEdge.Domain.Abstracts
{
    public interface IDbContext
    {
        EdgeDbContext GetDbContext();
    }
}
